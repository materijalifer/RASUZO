U ovom repozitoriju se nalazi sken moje bilježnice za zadatke iz Raspoznavanja Uzoraka
okademske godine 2011/2012.

Ovo mi je drugi put da slušam ovaj predmet i toliko sam bjesomučno rješavao zadatke da sam
ih stvarno puno rješio :)
Pa evo, nadam se da će vam poslužiti i da nećete izgubiti masu vremena kao ja dok sam
razbijao glavu oko tih zadataka...

Rješio sam sve zadatke koji su se obrađivali te ak. godine. Neki su izbačeni poput
potencijalnih funkcija i neuronskih mreža. Ako ih profesor vrati budućih ak. godina, 
imate na fer2 materijalima razne auditorne u kojima je to rješeno.

U svakom tipu zadataka kojeg sam prvog rješavao sam pisao tekstualne upute kako bi se
mogao brzo podsjetiti o čemu se tu radi, nadam se da će to pomoći oko razumijevanja zadataka.
Gdje god sam rješavao neki konkretan zadatak, stavio sam i sliku tog zadatka da ne morate
kopati po raznim materijalima.

Poruka budućim generacijama, predmet je načelno zanimljiv ali pazite se teorije i pragova
na ispitima, moja preporuka je ako ne možete zapamtiti izvode, koncentrirajte se na zadatke
koji su šablona. Ja sam dobio iz oba ispita 100% iz zadataka i nešto sitno na teoriji,
dovoljno da prođem ovu "divotu" od predmeta...

Ukratko o meni, ja sam Krešimir Špes i ovo mi je bio zadnji ispit u životu,
kao i ostatak faksa - prožet mukom i stresom...
Presretan sam da sam se napokon rješio tog faksa temogu krenut dalje u život slobodan
ko ptica :) Nadam se da ćete i vi uskoro!

I za kraj, molio bih vas, ako vam se da i ako su vam ovi materijali pomogli, da mi samo
napišete kratki email na kspes@cateia.com , čisto da se povremeno sjetim ovog predmeta
i u kojoj god situaciji bio, uvijek se mogu sjetiti da je nekome u tom trenutku
sigurno gore nego meni jer sluša RASZUZO :D

Puno sreće na ovom predmetu vam želim! Nemojte podcijenit pragove i teoriju i pamet u glavu!
